res_fpath = '';
gt_fpath = '';

evaluateDetection(res_fpath, gt_fpath, 'wildtrack');